import pandas as pd
import os
import sys
import re

class Tree():
    def __init__(self):
        pass

    def ask_question(self):
        return self.question

    def check_answer(self,answer):
        if answer == self.answerTrue:
            return self.leftNode
        elif answer == self.answerFalse:
            return self.rightNode
        else:
            return False

texto = pd.read_csv("PE_perguntas.csv",sep=',',index_col="ID")
dados = pd.read_csv("dados.csv",sep=',',index_col="GRUPO")

def define_Grupo(preco):
    for i in range(6):
      row = dados.loc[i+1]
      if preco >= float(row["L_INF"]) and preco <= float(row["L_SUP"]):
          grupo = i+1
          return grupo
    return 8

def build_Tabela(grupo,tema):
    if tema == "GRUPO":
        return "Seu grupo é: "+grupo
    row = dados.loc[grupo]
    print("--",end="")
    for c in tema:
        print("-",end="")
    print("--")
    print("| "+tema+" |")
    print("--",end="")
    for c in tema:
        print("-",end="")
    print("--")
    media = float(row["M_"+tema].replace(",", "."))
    desvio = 0.67*float(row["D_"+tema].replace(",", "."))
    print("0 se "+tema+" < "+str(round((media-desvio),2)))
    print("1 se "+str(round((media-desvio),2))+" ≤ "+tema+" ≤ "+str(round((media+desvio),2)))
    print("2 se "+str(round((media+desvio),2))+" < "+tema)
    print("--",end="")
    for c in tema:
        print("-",end="")
    print("--")

def rec_build_tree(linha):
    row = texto.loc[linha]
    if row["Pergunta"] == "NÓ FOLHA":
        return row["A"]
    node = Tree()
    node.leftNode = rec_build_tree(int(row["Nó A"]))
    node.rightNode = rec_build_tree(int(row["Nó B"]))
    node.question = row["Pergunta"]
    node.answerTrue = row["A"]
    node.answerFalse = row["B"]
    return node

def is_obj(obj):
    return False if type(obj).__name__ == "str" else True

def maiusc(s):
    patterns= ['[A-Z]{2,}(?:\s+[A-Z]+)*']  
    for p in patterns:
        match= re.findall(p, s)[0]
    return match

counter_tickets = 0
while True:
    arvore = rec_build_tree(1)
    count_erros=0
    preco = float(input("Qual o preço da sua casa? (use pontos ao inves de virgulas) \n"))
    grupo = define_Grupo(preco)
    while True:
        if count_erros == 2:
            print("ERROS SUCESSIVOS\nVERIFIQUE AS OPÇÕES ANTES DE TENTAR NOVAMENTE\n")
            print("\nMuitas informações! :/ \nPor favor me reinicie.")
            break
        opcoes = {1:arvore.answerTrue,2:arvore.answerFalse}
        print("\nEscolha uma das opções abaixo:"+"\n0 para sair"+"\n1 para "+opcoes[1]+"\n2 para "+opcoes[2]+"\n")
        build_Tabela(grupo,maiusc(str(arvore.ask_question())))
        response = input(arvore.ask_question()+"\n")
        while not response.isnumeric():
            if count_erros == 2:
                print("\nMuitas informações! :/ \nPor favor me reinicie.")
                sys.exit()
            print("\nMe desculpe, não conheço essa opção, vamos tentar novamente? :)\n")
            print("Escolha uma das opções abaixo:"+"\n0 para sair"+"\n1 para "+opcoes[1]+"\n2 para "+opcoes[2])
            response = input(arvore.ask_question())
            count_erros+=1

        if int(response) == 0:
            print("\nFim.\n")
            sys.exit()

        question = opcoes[int(response)]
        answer = arvore.check_answer(question)
        if answer == False:
            print("\nMe desculpe, não conheço essa opção, vamos tentar novamente? :)")
            count_erros+=1
        elif not is_obj(answer):
            break
        else:
            arvore = answer

    print(answer)

    print("-------------------------------------")
