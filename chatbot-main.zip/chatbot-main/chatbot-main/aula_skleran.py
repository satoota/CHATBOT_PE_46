import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.model_selection import train_test_split

train = pd.read_excel('PE - resultado Treino.xlsx', sheet_name='Dados')
y_train = train['caro']
x_train = train.drop(['caro'], axis=1).values
decision_tree = tree.DecisionTreeClassifier(max_depth = 20,min_samples_split = 9)
decision_tree.fit(x_train, y_train)

with open("aula.dot", 'w') as f:
     f = tree.export_graphviz(decision_tree,
                              out_file=f,
                              max_depth = 20,
                              impurity = True,
                              feature_names = list(train.drop(['caro'], axis=1)),
                              class_names = ['Barato', 'Média','Caro'],
                              rounded = True,
                              filled= True )

print(decision_tree.predict([[4,1,2,2,0,2,1,1,0,1,2,0]]))
print(decision_tree.predict([[2,1,2,0,0,2,1,1,1,1,0,1]]))
print(decision_tree.predict([[2,1,1,1,0,2,1,1,1,1,1,0]]))
print(decision_tree.predict([[2,0,1,0,0,2,1,1,1,1,0,1]]))
print(decision_tree.predict([[2,0,1,0,0,2,1,1,1,1,0,1]]))
print(decision_tree.predict([[3,1,0,0,0,1,1,1,0,1,1,0]]))
print(decision_tree.predict([[2,1,2,1,0,2,1,1,1,1,0,2]]))
print(decision_tree.predict([[2,1,1,1,0,2,1,1,1,2,2,0]]))
print(decision_tree.predict([[4,1,2,2,1,1,1,1,0,2,2,0]]))
print(decision_tree.predict([[2,0,0,0,0,2,1,1,1,2,0,0]]))










